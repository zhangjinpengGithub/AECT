#python run_gc_adj.py -b ../data/bam/PA209U0237-C5C9H20XNF1-H001K799Y00D.5X.sort.dedup.bam --bed ../data/tss.sort.bed  --genome2bit /dssg/home/zhangjp/database/hg19/genome/hs37d5.fa.2bit --threads 30
import sys
import os
#conda activate fram_arm
#python get_TSS_fragsh.py ../filter_bam/bam_path > TSS.sh

if not os.path.exists('./data/'):  
    # 创建目录  
    os.makedirs('./data/')
with open (sys.argv[1]) as f:
    for i in f:
        line=i.strip()+".gc.bam"
        name=line.split("/")[-1].split(".")[0]
        print("python /dssg/home/zhangjp/model_predict/KZ58/12.28/Focal_cnv_base/TSS/TSS_frag_ratio.py " + line +" /dssg/home/zhangjp/model_predict/2023_1124_bam/R01B/Feature_sele/12.29/TSS2711.bed  "+name)
