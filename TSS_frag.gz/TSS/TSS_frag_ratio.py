import sys
import time
from pathlib import Path
import subprocess
import itertools
from multiprocessing import Pool
import pysam
import pandas as pd
import argparse


def calculate_fragment_ratio(bam, chrname, tss_start, tss_end):
    # 打开BAM文件
#    bam = pysam.AlignmentFile(bam_file, "rb")
    
    # 初始化长短片段计数器
    short_fragments = 0
    long_fragments = 0
    
    # 遍历TSS位点上的reads
    for read in bam.fetch(str(chrname), int(tss_start), int(tss_end)):
        if ( 100<=abs(read.template_length)<=300 and read.is_paired and read.mapping_quality >= 20 and read.mate_is_mapped and not read.is_duplicate and not read.is_secondary and read.is_qcfail==False):
        # 检查read长度
            gc_corrected_depth = float(read.query_name.split(":gc:")[-1])
            if abs(read.template_length) > 150 :
                long_fragments += gc_corrected_depth
            elif abs(read.template_length) <150:
                short_fragments += gc_corrected_depth
            
    # 计算并返回长短片段比值
#    if short_fragments == 0:
#        return float('inf')  # 如果没有短片段，返回无穷大
#    else:
    return float(long_fragments), float(short_fragments)


bam_file=sys.argv[1]
name_out=sys.argv[3]
bam_file = pysam.AlignmentFile(bam_file, "rb")
TSS_bed=sys.argv[2]
TSS_bed=pd.read_table(TSS_bed,header=None)
TSS_bed.columns=['chr','start','end','gene']
fraglist=[]
genelist=[]
for x in TSS_bed.itertuples():
    longfrag,shortfrag=calculate_fragment_ratio(bam_file,x.chr,x.start,x.end)
    fraglist.append(longfrag)
    genelist.append(x.gene)
#    fraglist.append(shortfrag)
#    genelist.append(x.gene+"short")

df=pd.DataFrame({'gene':genelist,'frag': fraglist})
total_reads = df['frag'].sum()
df['frag']=df['frag'].apply(lambda x:x*1000/total_reads)
df=df.T
df.insert(0, 'SampleID', ['SampleID',name_out])
df.to_csv("./data/"+name_out,sep=",",index=False,header=None)
 
