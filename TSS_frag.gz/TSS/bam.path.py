import os
#work="/dssg/home/zhangjp/cnv/202308pancer_cnv/bam/"

import os,sys
### /dssg/home/sheny/software/own/gsml/gsml search_bam -f Healthy.bam.id  -o ./bam
work=sys.argv[1]

tsv_files = [f for f in os.listdir(work) if f.endswith('bam')]
for i in tsv_files:
    c=work+"/"+i
    print(c)
