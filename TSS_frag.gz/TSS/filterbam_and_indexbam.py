import os,sys
# ./
work=sys.argv[2]
if not os.path.exists(work+"filter_bam"):
    os.makedirs(work+"filter_bam")

#bam_path
with open(sys.argv[1]) as f:
    for line in f:
        line=line.strip()
        name=line.split("/")[-1].split(".")[0]
        cmd="samtools view -hF 1024 "+line+"""  |awk '{if($0 ~ "^@" || $5 > 15){print}}'|samtools view -bS - > """+work+"""filter_bam/"""+name+".filter.bam  && samtools index "+work+"filter_bam/"+name+".filter.bam"
        print(cmd)
